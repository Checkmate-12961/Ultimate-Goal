
# Active Detectors
[Sampling Order Detector](/detectors/SamplingOrder)     
[Gold Align Detector](/detectors/GoldAlign)         
[Gold Detector](/detectors/SamplingOrder)    
# Legacy Detectors
[Cryptobox Detector](/detectors/Cryptobox)     
[Jewel Order Detector](/detectors/Jewel)    
[Generic Detector](/detectors/Generic) (Will be ported soon)    